// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xsqueezenet.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSqueezenet_CfgInitialize(XSqueezenet *InstancePtr, XSqueezenet_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSqueezenet_Start(XSqueezenet *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSqueezenet_IsDone(XSqueezenet *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSqueezenet_IsIdle(XSqueezenet *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSqueezenet_IsReady(XSqueezenet *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSqueezenet_EnableAutoRestart(XSqueezenet *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSqueezenet_DisableAutoRestart(XSqueezenet *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_AP_CTRL, 0);
}

void XSqueezenet_Set_input_r(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_input_r(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_Set_output_r(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_output_r(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_Set_conv1w(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV1W_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV1W_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_conv1w(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV1W_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV1W_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_Set_conv2w(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV2W_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV2W_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_conv2w(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV2W_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV2W_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_Set_conv3w(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV3W_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV3W_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_conv3w(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV3W_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV3W_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_Set_conv4w(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV4W_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV4W_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_conv4w(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV4W_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV4W_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_Set_conv5w(XSqueezenet *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV5W_DATA, (u32)(Data));
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV5W_DATA + 4, (u32)(Data >> 32));
}

u64 XSqueezenet_Get_conv5w(XSqueezenet *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV5W_DATA);
    Data += (u64)XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_CONV5W_DATA + 4) << 32;
    return Data;
}

void XSqueezenet_InterruptGlobalEnable(XSqueezenet *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_GIE, 1);
}

void XSqueezenet_InterruptGlobalDisable(XSqueezenet *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_GIE, 0);
}

void XSqueezenet_InterruptEnable(XSqueezenet *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_IER);
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_IER, Register | Mask);
}

void XSqueezenet_InterruptDisable(XSqueezenet *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_IER);
    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSqueezenet_InterruptClear(XSqueezenet *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSqueezenet_WriteReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_ISR, Mask);
}

u32 XSqueezenet_InterruptGetEnabled(XSqueezenet *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_IER);
}

u32 XSqueezenet_InterruptGetStatus(XSqueezenet *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSqueezenet_ReadReg(InstancePtr->Control_BaseAddress, XSQUEEZENET_CONTROL_ADDR_ISR);
}

