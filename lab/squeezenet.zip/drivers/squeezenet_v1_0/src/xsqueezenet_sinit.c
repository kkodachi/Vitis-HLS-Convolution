// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2021.1 (64-bit)
// Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xsqueezenet.h"

extern XSqueezenet_Config XSqueezenet_ConfigTable[];

XSqueezenet_Config *XSqueezenet_LookupConfig(u16 DeviceId) {
	XSqueezenet_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSQUEEZENET_NUM_INSTANCES; Index++) {
		if (XSqueezenet_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSqueezenet_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSqueezenet_Initialize(XSqueezenet *InstancePtr, u16 DeviceId) {
	XSqueezenet_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSqueezenet_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSqueezenet_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

